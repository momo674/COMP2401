Program Author: Mohamad Radaideh 101292701.
Purpose: Work for lab2 to learn the syntax and basics of C.
Files: hello.c, divisor.c, primes.c aswell as README.txt.


Launching Insutructions: 
hello.c ->
    gcc -Wall -o hello_output hello.c 
    ./hello_output

divisor.c ->
    In main(), call the function in a print statement with desired numbers.
    gcc -Wall -o divisor_output divisor.c 
    ./divisor_output
primes.c ->
    In main(), call the function "primes(n)" with a desired input n.
    gcc -Wall -o primes_output primes.c 
    ./primes_output



